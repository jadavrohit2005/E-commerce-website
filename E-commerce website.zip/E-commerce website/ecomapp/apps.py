# from django.apps import AppConfig


# class EcomappConfig(AppConfig):
#     name = 'ecomapp'

from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    user_logged_in = True  # The Python condition/variable
    return render_template('index.html', logged_in=user_logged_in)

if __name__ == '__main__':
    app.run(debug=True)
